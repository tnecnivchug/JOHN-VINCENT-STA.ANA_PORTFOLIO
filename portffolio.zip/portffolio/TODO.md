# TODO: Add Simple Animations to Education and Skills Sections

## Tasks
- [x] Add simple fade-in animations to .education-item and .skill-item in vincent.CSS
- [ ] Ensure animations work on both desktop and mobile without blinking
- [ ] Test animations by scrolling through sections

## Notes
- Use CSS keyframes for fade-in effect
- Keep animations simple and smooth
- Maintain existing IntersectionObserver logic

# TODO: Reduce Profile Image Size

## Tasks
- [x] Reduce .profile-image img width and height from 200px to 160px in vincent.CSS
- [x] Ensure the change prevents overlap with other page content
- [x] Test the layout on different screen sizes

## Notes
- Keep the circular shape and other styling intact
- Adjusted to 160px as confirmed by user
- Responsive sizes remain proportional
